import os
import shutil
import random
import numpy as np
from tensorflow.keras.preprocessing.image import load_img, img_to_array
from sklearn.model_selection import train_test_split

# Define dataset paths
DATA_DIR = "C:/Users/harsh/diabetes detection/data"
DIABETIC_DIR = os.path.join(DATA_DIR, "C:/Users/harsh/diabetes detection/data/diabetic dataset")
NON_DIABETIC_DIR = os.path.join(DATA_DIR, "C:/Users/harsh/diabetes detection/data/nondiabetic dataset")

# Output directories for train, test, val
TRAIN_DIR = os.path.join(DATA_DIR, "train")
TEST_DIR = os.path.join(DATA_DIR, "test")
VAL_DIR = os.path.join(DATA_DIR, "val")

# Ensure output directories exist
for folder in [TRAIN_DIR, TEST_DIR, VAL_DIR]:
    os.makedirs(os.path.join(folder, "diabetic dataset"), exist_ok=True)
    os.makedirs(os.path.join(folder, "nondiabetic dataset"), exist_ok=True)

# Function to load images from a folder
def load_images_from_folder(folder, label):
    images, labels = [], []
    for patient in os.listdir(folder):
        patient_path = os.path.join(folder, patient)
        if os.path.isdir(patient_path):
            for img_file in os.listdir(patient_path):
                img_path = os.path.join(patient_path, img_file)
                img = load_img(img_path, target_size=(224, 224))  # Resize
                img_array = img_to_array(img) / 255.0  # Normalize
                images.append(img_array)
                labels.append(label)
    return images, labels

# Load images from both classes
diabetic_images, diabetic_labels = load_images_from_folder(DIABETIC_DIR, label=1)
non_diabetic_images, non_diabetic_labels = load_images_from_folder(NON_DIABETIC_DIR, label=0)

# Combine dataset
X = np.array(diabetic_images + non_diabetic_images)
y = np.array(diabetic_labels + non_diabetic_labels)

# Split dataset (70% train, 20% test, 10% val)
X_train, X_temp, y_train, y_temp = train_test_split(X, y, test_size=0.3, random_state=42, stratify=y)
X_test, X_val, y_test, y_val = train_test_split(X_temp, y_temp, test_size=0.33, random_state=42, stratify=y_temp)

# Function to save images into corresponding folders
def save_images(X, y, folder):
    for i, img_array in enumerate(X):
        subfolder = "diabetic" if y[i] == 1 else "nondiabetic"
        save_path = os.path.join(folder, subfolder, f"image_{i}.png")
        img = (img_array * 255).astype(np.uint8)  # Convert back to image format
        load_img(save_path).save(save_path)

# Save preprocessed images into respective folders
save_images(X_train, y_train, TRAIN_DIR)
save_images(X_test, y_test, TEST_DIR)
save_images(X_val, y_val, VAL_DIR)

print("✅ Data preprocessing completed successfully!")
